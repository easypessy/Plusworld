import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
  onScheduleTour: () => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate, onScheduleTour }) => {
  return (
    <footer className="bg-[#0d1f1a] text-[#fbe7c5]/60">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-9 h-9 bg-[#fbe7c5] flex items-center justify-center flex-shrink-0">
                <span className="text-[#144d3c] font-bold text-lg font-['Cormorant_Garamond']">P</span>
              </div>
              <div>
                <div className="text-[#fbe7c5] font-['Cormorant_Garamond'] font-semibold text-xl leading-none">
                  PLUSWORLD
                </div>
                <div className="text-[#fbe7c5]/40 text-[8px] tracking-[0.2em] uppercase font-['Inter'] mt-0.5">
                  Realtors & Investment
                </div>
              </div>
            </div>
            <p className="text-[#fbe7c5]/40 text-xs font-['Inter'] font-light leading-relaxed mb-6">
              Lagos' premier quiet luxury real estate agency. Curating the finest properties across Lekki, Victoria Island, and Ibeju-Lekki since 2018.
            </p>
            <div className="flex items-center gap-3">
              {['IG', 'LI', 'X'].map((label) => (
                <a
                  key={label}
                  href="#"
                  className="w-8 h-8 border border-[#fbe7c5]/15 flex items-center justify-center hover:border-[#fbe7c5]/40 hover:text-[#fbe7c5] transition-colors text-[10px] font-['Inter'] font-semibold"
                >
                  {label}
                </a>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div>
            <div className="text-[#fbe7c5] text-[10px] tracking-[0.25em] uppercase font-['Inter'] mb-5">Navigate</div>
            <div className="space-y-3">
              {[
                { label: 'Home', page: 'home' },
                { label: 'Property Listings', page: 'listings' },
                { label: 'Investor Portal', page: 'investor' },
                { label: 'About Us', page: 'about' },
              ].map(link => (
                <button
                  key={link.page}
                  onClick={() => onNavigate(link.page)}
                  className="block text-[#fbe7c5]/40 text-xs font-['Inter'] hover:text-[#fbe7c5] transition-colors text-left"
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={onScheduleTour}
                className="block text-[#fbe7c5]/40 text-xs font-['Inter'] hover:text-[#fbe7c5] transition-colors text-left"
              >
                Book Private Viewing
              </button>
            </div>
          </div>

          {/* Locations */}
          <div>
            <div className="text-[#fbe7c5] text-[10px] tracking-[0.25em] uppercase font-['Inter'] mb-5">Markets</div>
            <div className="space-y-3">
              {[
                'Lekki Phase 1 & 2',
                'Victoria Island',
                'Ibeju-Lekki',
                'Chevron Drive',
                'Ikate-Elegushi',
                'Ajah & Sangotedo',
              ].map(location => (
                <div key={location} className="text-[#fbe7c5]/40 text-xs font-['Inter']">
                  {location}
                </div>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div>
            <div className="text-[#fbe7c5] text-[10px] tracking-[0.25em] uppercase font-['Inter'] mb-5">Contact</div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin size={13} className="text-[#fbe7c5]/30 mt-0.5 flex-shrink-0" />
                <div className="text-xs font-['Inter'] text-[#fbe7c5]/40 leading-relaxed">
                  15 Adeola Odeku Street<br />Victoria Island, Lagos
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={13} className="text-[#fbe7c5]/30 flex-shrink-0" />
                <a href="tel:+2348000000000" className="text-xs font-['Inter'] text-[#fbe7c5]/40 hover:text-[#fbe7c5] transition-colors">
                  +234 800 000 0000
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={13} className="text-[#fbe7c5]/30 flex-shrink-0" />
                <a href="mailto:concierge@plusworld.ng" className="text-xs font-['Inter'] text-[#fbe7c5]/40 hover:text-[#fbe7c5] transition-colors">
                  concierge@plusworld.ng
                </a>
              </div>
            </div>

            <div className="mt-6 p-4 border border-[#fbe7c5]/10 bg-[#fbe7c5]/3">
              <div className="text-[#fbe7c5]/30 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-2">Office Hours</div>
              <div className="text-[#fbe7c5]/50 text-xs font-['Inter']">Mon – Fri: 8:00am – 7:00pm WAT</div>
              <div className="text-[#fbe7c5]/50 text-xs font-['Inter']">Saturday: 9:00am – 5:00pm WAT</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#fbe7c5]/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-[#fbe7c5]/25 text-[10px] font-['Inter'] tracking-wide">
            © 2026 Plusworld Realtors and Investment Limited. All Rights Reserved.
          </div>
          <div className="flex items-center gap-6">
            {['Privacy Policy', 'Terms of Service', 'Legal'].map(item => (
              <span key={item} className="text-[#fbe7c5]/25 text-[10px] font-['Inter'] cursor-pointer hover:text-[#fbe7c5]/50 transition-colors">
                {item}
              </span>
            ))}
          </div>
          <div className="text-[#fbe7c5]/15 text-[10px] font-['Inter']">
            NIESV Verified · RC 1234567
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
