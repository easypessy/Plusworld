import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

interface NavbarProps {
  onScheduleTour: () => void;
  currentPage: string;
  onNavigate: (page: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ onScheduleTour, currentPage, onNavigate }) => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'listings', label: 'Listings' },
    { id: 'investor', label: 'Investor Portal' },
    { id: 'about', label: 'About' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled || menuOpen
            ? 'bg-[#0d3529]/95 backdrop-blur-lg shadow-2xl'
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-3 group"
          >
            <div className="w-9 h-9 bg-[#fbe7c5] rounded-sm flex items-center justify-center">
              <span className="text-[#144d3c] font-bold text-lg font-['Cormorant_Garamond']">P</span>
            </div>
            <div className="text-left">
              <div className="text-[#fbe7c5] font-['Cormorant_Garamond'] font-semibold text-xl leading-none tracking-wide">
                PLUSWORLD
              </div>
              <div className="text-[#fbe7c5]/60 text-[9px] tracking-[0.2em] uppercase font-['Inter'] leading-none mt-0.5">
                Realtors & Investment
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => onNavigate(link.id)}
                className={`text-sm tracking-[0.12em] uppercase font-['Inter'] transition-colors duration-300 ${
                  currentPage === link.id
                    ? 'text-[#fbe7c5]'
                    : 'text-[#fbe7c5]/60 hover:text-[#fbe7c5]'
                }`}
              >
                {link.label}
                {currentPage === link.id && (
                  <div className="h-px bg-[#fbe7c5]/60 mt-0.5 w-full" />
                )}
              </button>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="tel:+2348000000000"
              className="flex items-center gap-2 text-[#fbe7c5]/70 hover:text-[#fbe7c5] text-sm font-['Inter'] transition-colors"
            >
              <Phone size={14} />
              <span>+234 800 000 0000</span>
            </a>
            <button
              onClick={onScheduleTour}
              className="magnetic-btn bg-[#fbe7c5] text-[#144d3c] px-5 py-2.5 text-xs tracking-[0.18em] uppercase font-['Inter'] font-semibold hover:bg-white transition-all duration-300 hover:shadow-[0_0_30px_rgba(251,231,197,0.3)]"
            >
              Schedule Tour
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-[#fbe7c5] p-2"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden bg-[#0d3529] border-t border-[#fbe7c5]/10 px-6 pb-8 pt-4">
            <div className="flex flex-col gap-5">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => { onNavigate(link.id); setMenuOpen(false); }}
                  className={`text-left text-lg font-['Cormorant_Garamond'] transition-colors ${
                    currentPage === link.id ? 'text-[#fbe7c5]' : 'text-[#fbe7c5]/60'
                  }`}
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => { onScheduleTour(); setMenuOpen(false); }}
                className="bg-[#fbe7c5] text-[#144d3c] py-3 text-xs tracking-[0.18em] uppercase font-['Inter'] font-semibold mt-2"
              >
                Schedule Private Tour
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Sticky Tour Button */}
      <div className="fixed bottom-8 right-8 z-40">
        <button
          onClick={onScheduleTour}
          className="group flex items-center gap-3 bg-[#144d3c] text-[#fbe7c5] pl-5 pr-6 py-4 shadow-2xl hover:bg-[#1a6650] transition-all duration-300 hover:shadow-[0_8px_40px_rgba(20,77,60,0.5)] hover:scale-105 active:scale-95"
          style={{ borderRadius: '50px' }}
        >
          <div className="w-2 h-2 rounded-full bg-[#fbe7c5] animate-pulse" />
          <span className="text-xs tracking-[0.15em] uppercase font-['Inter'] font-semibold whitespace-nowrap">
            Book Private Viewing
          </span>
        </button>
      </div>
    </>
  );
};

export default Navbar;
