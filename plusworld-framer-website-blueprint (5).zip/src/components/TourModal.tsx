import React, { useState, useEffect } from 'react';
import { X, CheckCircle, Calendar, User, Mail, Phone, MapPin } from 'lucide-react';

interface TourModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProperty?: string;
}

const TourModal: React.FC<TourModalProps> = ({ isOpen, onClose, selectedProperty }) => {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    location: selectedProperty || '',
    date: '',
    message: '',
  });

  useEffect(() => {
    if (selectedProperty) setForm(f => ({ ...f, location: selectedProperty }));
  }, [selectedProperty]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      setSubmitted(false);
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-[#0d1f1a]/80 backdrop-blur-sm" />

      {/* Modal */}
      <div className="relative bg-[#fafaf8] max-w-xl w-full max-h-[92vh] overflow-y-auto shadow-[0_40px_100px_rgba(0,0,0,0.4)] animate-modalIn">
        {/* Header */}
        <div className="bg-[#144d3c] px-8 pt-10 pb-8 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-[#fbe7c5]/60 hover:text-[#fbe7c5] transition-colors p-1"
          >
            <X size={20} />
          </button>
          <div className="text-[#fbe7c5]/60 text-[10px] tracking-[0.25em] uppercase font-['Inter'] mb-2">
            Plusworld Private Access
          </div>
          <h2 className="text-[#fbe7c5] font-['Cormorant_Garamond'] text-3xl font-light leading-tight">
            Schedule a Private Viewing
          </h2>
          <p className="text-[#fbe7c5]/60 text-sm font-['Inter'] font-light mt-2">
            Our concierge team will confirm within 2 hours.
          </p>
        </div>

        {/* Body */}
        <div className="px-8 py-8">
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Name */}
              <div className="relative">
                <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={e => setForm({...form, name: e.target.value})}
                    className="w-full pl-9 pr-4 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] placeholder:text-[#144d3c]/30 transition-colors"
                    placeholder="Your full name"
                  />
                </div>
              </div>

              {/* Email + Phone */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                    Email
                  </label>
                  <div className="relative">
                    <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={e => setForm({...form, email: e.target.value})}
                      className="w-full pl-9 pr-3 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] placeholder:text-[#144d3c]/30 transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                    Phone
                  </label>
                  <div className="relative">
                    <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
                    <input
                      type="tel"
                      required
                      value={form.phone}
                      onChange={e => setForm({...form, phone: e.target.value})}
                      className="w-full pl-9 pr-3 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] placeholder:text-[#144d3c]/30 transition-colors"
                      placeholder="+234 ..."
                    />
                  </div>
                </div>
              </div>

              {/* Property Interest */}
              <div>
                <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                  Property / Location Interest
                </label>
                <div className="relative">
                  <MapPin size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
                  <select
                    value={form.location}
                    onChange={e => setForm({...form, location: e.target.value})}
                    className="w-full pl-9 pr-4 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors appearance-none"
                  >
                    <option value="">Select property or location</option>
                    <option value="Lekki Phase 1">Lekki Phase 1</option>
                    <option value="Victoria Island">Victoria Island</option>
                    <option value="Ibeju-Lekki">Ibeju-Lekki</option>
                    <option value="The Meridian Residence">The Meridian Residence</option>
                    <option value="Skyline Penthouse VI">Skyline Penthouse VI</option>
                    <option value="Lagoon Crest Estate">Lagoon Crest Estate</option>
                    <option value="Other">Other / Open to Suggestions</option>
                  </select>
                </div>
              </div>

              {/* Date */}
              <div>
                <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                  Preferred Date
                </label>
                <div className="relative">
                  <Calendar size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
                  <input
                    type="date"
                    value={form.date}
                    onChange={e => setForm({...form, date: e.target.value})}
                    className="w-full pl-9 pr-4 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors"
                  />
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-[10px] tracking-[0.2em] uppercase text-[#144d3c]/60 font-['Inter'] mb-1.5">
                  Additional Notes
                </label>
                <textarea
                  value={form.message}
                  onChange={e => setForm({...form, message: e.target.value})}
                  rows={3}
                  className="w-full px-4 py-3 bg-transparent border border-[#144d3c]/20 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] placeholder:text-[#144d3c]/30 transition-colors resize-none"
                  placeholder="Budget range, investment goals, or special requirements..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#144d3c] text-[#fbe7c5] py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-all duration-300 hover:shadow-[0_8px_30px_rgba(20,77,60,0.3)]"
              >
                Request Private Viewing
              </button>

              <p className="text-center text-[10px] text-[#144d3c]/40 font-['Inter'] tracking-wide">
                Your information is strictly confidential and never shared.
              </p>
            </form>
          ) : (
            <div className="text-center py-12">
              <div className="flex justify-center mb-6">
                <CheckCircle size={56} className="text-[#144d3c]" strokeWidth={1.5} />
              </div>
              <h3 className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c] mb-3">
                Request Received
              </h3>
              <p className="text-[#144d3c]/60 text-sm font-['Inter'] font-light max-w-xs mx-auto mb-8">
                Our concierge team will reach out to <span className="text-[#144d3c] font-medium">{form.email}</span> within 2 hours to confirm your private viewing.
              </p>
              <button
                onClick={onClose}
                className="text-xs tracking-[0.2em] uppercase font-['Inter'] text-[#144d3c]/60 hover:text-[#144d3c] border-b border-[#144d3c]/20 pb-0.5 transition-colors"
              >
                Close
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TourModal;
