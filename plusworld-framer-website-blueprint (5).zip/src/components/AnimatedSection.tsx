import React, { useEffect, useRef, useState } from 'react';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  animation?: 'fadeUp' | 'fadeIn' | 'slideLeft' | 'slideRight' | 'scaleIn';
  threshold?: number;
}

const AnimatedSection: React.FC<AnimatedSectionProps> = ({
  children,
  className = '',
  delay = 0,
  animation = 'fadeUp',
  threshold = 0.15,
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(el);
        }
      },
      { threshold }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [threshold]);

  const animations: Record<string, { from: string; to: string }> = {
    fadeUp: {
      from: 'opacity-0 translate-y-10',
      to: 'opacity-100 translate-y-0',
    },
    fadeIn: {
      from: 'opacity-0',
      to: 'opacity-100',
    },
    slideLeft: {
      from: 'opacity-0 translate-x-12',
      to: 'opacity-100 translate-x-0',
    },
    slideRight: {
      from: 'opacity-0 -translate-x-12',
      to: 'opacity-100 translate-x-0',
    },
    scaleIn: {
      from: 'opacity-0 scale-95',
      to: 'opacity-100 scale-100',
    },
  };

  const { from, to } = animations[animation];

  return (
    <div
      ref={ref}
      className={`transition-all duration-1000 ease-out ${visible ? to : from} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
};

export default AnimatedSection;
