import React, { useState, useRef } from 'react';
import { Bed, Bath, Square, TrendingUp, Shield, MapPin, ArrowUpRight } from 'lucide-react';
import { Property } from '../data/properties';

interface PropertyCardProps {
  property: Property;
  onView: (property: Property) => void;
  onScheduleTour: (title: string) => void;
  index?: number;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property, onView, onScheduleTour, index = 0 }) => {
  const [hovered, setHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const tierColors: Record<string, string> = {
    Premium: 'bg-[#fbe7c5] text-[#144d3c]',
    High: 'bg-[#144d3c]/10 text-[#144d3c]',
    Medium: 'bg-slate-100 text-slate-600',
  };

  const statusColors: Record<string, string> = {
    Available: 'text-emerald-600',
    'Under Offer': 'text-amber-600',
    Sold: 'text-red-500',
  };

  return (
    <div
      ref={cardRef}
      className="group relative bg-white overflow-hidden cursor-pointer transition-all duration-500 hover:shadow-[0_30px_80px_rgba(20,77,60,0.15)] hover:-translate-y-1"
      style={{ animationDelay: `${index * 100}ms` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => onView(property)}
    >
      {/* Image Container */}
      <div className="relative h-64 overflow-hidden bg-[#0d3529]">
        <img
          src={property.image}
          alt={property.title}
          className={`w-full h-full object-cover transition-transform duration-700 ${hovered ? 'scale-110' : 'scale-100'}`}
        />

        {/* Overlay on Hover */}
        <div className={`absolute inset-0 bg-[#144d3c]/60 flex items-center justify-center transition-opacity duration-500 ${hovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className="text-center">
            <div className="text-[#fbe7c5] font-['Cormorant_Garamond'] text-xl font-light mb-3">
              View Property
            </div>
            <div className="w-10 h-px bg-[#fbe7c5]/60 mx-auto" />
          </div>
        </div>

        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {property.verified && (
            <span className="flex items-center gap-1.5 bg-[#144d3c] text-[#fbe7c5] text-[9px] tracking-[0.2em] uppercase px-2.5 py-1.5 font-['Inter'] font-semibold">
              <Shield size={9} />
              Verified
            </span>
          )}
          {property.featured && (
            <span className="bg-[#fbe7c5] text-[#144d3c] text-[9px] tracking-[0.2em] uppercase px-2.5 py-1.5 font-['Inter'] font-semibold">
              Featured
            </span>
          )}
        </div>

        {/* Status */}
        <div className="absolute top-4 right-4">
          <span className={`text-[9px] tracking-[0.2em] uppercase font-['Inter'] font-semibold ${statusColors[property.status]}`}>
            ● {property.status}
          </span>
        </div>

        {/* Price Overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent px-4 pt-8 pb-4">
          <div className="text-[#fbe7c5] font-['Cormorant_Garamond'] text-2xl font-light">
            {property.priceLabel}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Location */}
        <div className="flex items-center gap-1.5 text-[#144d3c]/50 text-[10px] tracking-[0.15em] uppercase font-['Inter'] mb-2">
          <MapPin size={10} />
          {property.address}
        </div>

        {/* Title */}
        <h3 className="font-['Cormorant_Garamond'] text-xl text-[#144d3c] font-medium leading-tight mb-1">
          {property.title}
        </h3>
        <p className="text-[#144d3c]/50 text-xs font-['Inter'] font-light italic mb-4">
          {property.tagline}
        </p>

        {/* Stats */}
        {property.type !== 'Land' && (
          <div className="flex items-center gap-4 mb-4 pb-4 border-b border-[#144d3c]/8">
            <div className="flex items-center gap-1.5 text-[#144d3c]/60 text-xs font-['Inter']">
              <Bed size={13} className="text-[#144d3c]/40" />
              {property.bedrooms} Bed
            </div>
            <div className="flex items-center gap-1.5 text-[#144d3c]/60 text-xs font-['Inter']">
              <Bath size={13} className="text-[#144d3c]/40" />
              {property.bathrooms} Bath
            </div>
            <div className="flex items-center gap-1.5 text-[#144d3c]/60 text-xs font-['Inter']">
              <Square size={13} className="text-[#144d3c]/40" />
              {property.sqm.toLocaleString()} m²
            </div>
          </div>
        )}
        {property.type === 'Land' && (
          <div className="flex items-center gap-4 mb-4 pb-4 border-b border-[#144d3c]/8">
            <div className="flex items-center gap-1.5 text-[#144d3c]/60 text-xs font-['Inter']">
              <Square size={13} className="text-[#144d3c]/40" />
              {property.sqm.toLocaleString()} m²
            </div>
            <span className="text-xs font-['Inter'] text-[#144d3c]/50">{property.type}</span>
          </div>
        )}

        {/* ROI + Tier */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <TrendingUp size={13} className="text-emerald-600" />
            <span className="text-xs font-['Inter'] text-[#144d3c]/70">
              <span className="text-emerald-600 font-semibold">{property.roi}%</span> ROI
            </span>
          </div>
          <span className={`text-[9px] tracking-[0.15em] uppercase px-2.5 py-1 font-['Inter'] font-semibold ${tierColors[property.investmentTier]}`}>
            {property.investmentTier} Yield
          </span>
        </div>

        {/* CTA */}
        <div className="mt-4 flex gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); onScheduleTour(property.title); }}
            className="flex-1 border border-[#144d3c] text-[#144d3c] py-2.5 text-[9px] tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#144d3c] hover:text-[#fbe7c5] transition-all duration-300"
          >
            Book Viewing
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onView(property); }}
            className="flex items-center justify-center w-10 border border-[#144d3c]/20 text-[#144d3c]/60 hover:border-[#144d3c] hover:text-[#144d3c] transition-colors"
          >
            <ArrowUpRight size={15} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
