import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import TourModal from './components/TourModal';
import Home from './pages/Home';
import Listings from './pages/Listings';
import InvestorPortal from './pages/InvestorPortal';
import About from './pages/About';
import PropertyDetail from './pages/PropertyDetail';
import { Property } from './data/properties';

type Page = 'home' | 'listings' | 'investor' | 'about' | 'property';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [tourModalOpen, setTourModalOpen] = useState(false);
  const [tourPropertyTitle, setTourPropertyTitle] = useState<string | undefined>(undefined);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
    setSelectedProperty(null);
  };

  const handleViewProperty = (property: Property) => {
    setSelectedProperty(property);
    setCurrentPage('property');
  };

  const handleScheduleTour = (title?: string) => {
    setTourPropertyTitle(title);
    setTourModalOpen(true);
  };

  const handleBack = () => {
    setCurrentPage('listings');
    setSelectedProperty(null);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <Home
            onScheduleTour={handleScheduleTour}
            onNavigate={handleNavigate}
            onViewProperty={handleViewProperty}
          />
        );
      case 'listings':
        return (
          <Listings
            onScheduleTour={handleScheduleTour}
            onViewProperty={handleViewProperty}
          />
        );
      case 'investor':
        return <InvestorPortal onScheduleTour={handleScheduleTour} />;
      case 'about':
        return <About onScheduleTour={handleScheduleTour} />;
      case 'property':
        return selectedProperty ? (
          <PropertyDetail
            property={selectedProperty}
            onBack={handleBack}
            onScheduleTour={handleScheduleTour}
          />
        ) : null;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#fafaf8]">
      <Navbar
        onScheduleTour={() => handleScheduleTour()}
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />

      <main
        key={currentPage}
        style={{
          animation: 'fadeIn 0.4s ease forwards',
        }}
      >
        {renderPage()}
      </main>

      {currentPage !== 'property' && (
        <Footer
          onNavigate={handleNavigate}
          onScheduleTour={() => handleScheduleTour()}
        />
      )}
      {currentPage === 'property' && selectedProperty && (
        <Footer
          onNavigate={handleNavigate}
          onScheduleTour={() => handleScheduleTour()}
        />
      )}

      <TourModal
        isOpen={tourModalOpen}
        onClose={() => setTourModalOpen(false)}
        selectedProperty={tourPropertyTitle}
      />
    </div>
  );
}

export default App;
