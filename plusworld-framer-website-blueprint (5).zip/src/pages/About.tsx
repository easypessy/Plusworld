import React from 'react';
import { Award, Users, TrendingUp, Shield, Phone, Mail, MapPin } from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';

interface AboutProps {
  onScheduleTour: (title?: string) => void;
}

const About: React.FC<AboutProps> = ({ onScheduleTour }) => {
  const team = [
    {
      name: 'Oluwaseun Adeyemi',
      role: 'Founder & CEO',
      bio: 'Former Goldman Sachs Africa real estate analyst. 15+ years in luxury property investment across Lagos and Abuja.',
      avatar: '👔',
    },
    {
      name: 'Chidinma Okonkwo',
      role: 'Head of Acquisitions',
      bio: 'Expert in off-plan and waterfront property deals. Personally closed over ₦32B in transactions in the last 3 years.',
      avatar: '👩‍💼',
    },
    {
      name: 'Babatunde Fashola',
      role: 'Director, Investor Relations',
      bio: 'Diaspora investment specialist with clients across London, Houston, Dubai, and Toronto. MBA from LSE.',
      avatar: '🤵',
    },
    {
      name: 'Adaeze Nwosu',
      role: 'Legal & Compliance',
      bio: 'Property law specialist with 12 years experience in title verification, C of O processing, and investment structuring.',
      avatar: '⚖️',
    },
  ];

  const values = [
    {
      icon: Shield,
      title: 'Absolute Integrity',
      desc: 'Every property is legally verified before listing. We never compromise on title security or client trust.',
    },
    {
      icon: Award,
      title: 'Quiet Excellence',
      desc: 'We don\'t shout. We deliver. Our reputation is built on discretion, precision, and consistent outperformance.',
    },
    {
      icon: TrendingUp,
      title: 'Investment First',
      desc: 'Every recommendation is grounded in data. We treat your capital with the same care as our own.',
    },
    {
      icon: Users,
      title: 'Client Legacy',
      desc: 'Many of our clients are on their third or fourth investment with us. Long-term relationships are our business model.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#fafaf8] pt-20">
      {/* Hero */}
      <div className="relative h-80 lg:h-96 overflow-hidden bg-[#0d3529]">
        <img src="/images/about-bg.jpg" alt="Lagos" className="w-full h-full object-cover opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d3529]/80 to-transparent" />
        <div className="absolute inset-0 flex items-center max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection>
            <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">Our Story</div>
            <h1 className="font-['Cormorant_Garamond'] text-4xl lg:text-6xl text-[#fbe7c5] font-light">
              About Plusworld
            </h1>
          </AnimatedSection>
        </div>
      </div>

      {/* Mission */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <AnimatedSection animation="slideRight">
              <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-4">
                Est. Lagos, 2018
              </div>
              <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light leading-tight mb-6">
                Born from a Vision to<br />
                <span className="italic text-[#144d3c]/60">Elevate Nigerian Real Estate</span>
              </h2>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light text-sm leading-relaxed mb-5">
                Plusworld was founded in 2018 by Oluwaseun Adeyemi with a singular mission: to create a real estate experience worthy of Lagos' extraordinary ambition. At the time, high-end property transactions in Nigeria were opaque, cumbersome, and far beneath the quality that serious investors deserved.
              </p>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light text-sm leading-relaxed mb-5">
                We changed that. By combining rigorous legal due diligence, data-driven investment analysis, and a white-glove client experience, Plusworld became the agency of choice for Lagos' most discerning property buyers and investors.
              </p>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light text-sm leading-relaxed">
                Today, with over ₦87 billion in managed portfolio value, 340+ successful transactions, and clients across 4 continents, we remain committed to the quiet luxury ethos that defines everything we do.
              </p>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={200}>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { number: '8+', label: 'Years Operating' },
                  { number: '340+', label: 'Properties Sold' },
                  { number: '₦87B+', label: 'Portfolio Value' },
                  { number: '98%', label: 'Client Satisfaction' },
                ].map((stat) => (
                  <div key={stat.label} className="bg-[#fafaf8] border border-[#144d3c]/8 p-8 text-center">
                    <div className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light mb-2">
                      {stat.number}
                    </div>
                    <div className="text-[#144d3c]/40 text-[10px] tracking-[0.2em] uppercase font-['Inter']">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-[#144d3c]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Our Foundation
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#fbe7c5] font-light">
              The Plusworld Standard
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, i) => (
              <AnimatedSection key={value.title} animation="fadeUp" delay={i * 100}>
                <div className="border border-[#fbe7c5]/10 p-8 h-full hover:border-[#fbe7c5]/25 transition-colors">
                  <value.icon size={22} className="text-[#fbe7c5]/40 mb-6" strokeWidth={1.5} />
                  <h3 className="font-['Cormorant_Garamond'] text-xl text-[#fbe7c5] mb-3">{value.title}</h3>
                  <p className="text-[#fbe7c5]/40 text-sm font-['Inter'] font-light leading-relaxed">{value.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Leadership
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light">
              The Team Behind Plusworld
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, i) => (
              <AnimatedSection key={member.name} animation="fadeUp" delay={i * 100}>
                <div className="group text-center p-8 border border-[#144d3c]/8 hover:border-[#144d3c]/20 hover:shadow-[0_20px_50px_rgba(20,77,60,0.08)] transition-all duration-500">
                  <div className="w-20 h-20 bg-[#fafaf8] border border-[#144d3c]/10 rounded-full flex items-center justify-center text-4xl mx-auto mb-5 group-hover:bg-[#fbe7c5] transition-colors">
                    {member.avatar}
                  </div>
                  <h3 className="font-['Cormorant_Garamond'] text-xl text-[#144d3c] mb-1">{member.name}</h3>
                  <div className="text-[#144d3c]/40 text-[10px] tracking-[0.2em] uppercase font-['Inter'] mb-4">{member.role}</div>
                  <p className="text-[#144d3c]/50 text-xs font-['Inter'] font-light leading-relaxed">{member.bio}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="py-16 bg-[#fbe7c5]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection>
            <div className="flex flex-wrap justify-center items-center gap-8 lg:gap-16">
              {[
                { award: 'Best Luxury Agency', year: '2025', body: 'Nigeria Property Awards' },
                { award: 'Top Investment Advisor', year: '2024', body: 'Lagos Real Estate Forum' },
                { award: 'Excellence in Service', year: '2023', body: 'African Property Summit' },
                { award: 'Verified by NIESV', year: '2022', body: 'Nigerian Institution of Estate Surveyors' },
              ].map((item) => (
                <div key={item.award} className="text-center">
                  <Award size={20} className="text-[#144d3c]/40 mx-auto mb-2" />
                  <div className="font-['Cormorant_Garamond'] text-lg text-[#144d3c]">{item.award}</div>
                  <div className="text-[#144d3c]/50 text-[10px] tracking-[0.15em] uppercase font-['Inter']">
                    {item.year} · {item.body}
                  </div>
                </div>
              ))}
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Contact */}
      <section className="py-24 bg-white" id="contact">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16">
            <AnimatedSection animation="slideRight">
              <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-4">
                Get in Touch
              </div>
              <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light mb-8">
                Contact Our<br />
                <span className="italic text-[#144d3c]/60">Concierge Team</span>
              </h2>
              <div className="space-y-6">
                {[
                  { icon: Phone, label: 'Call Us', value: '+234 800 000 0000', sub: 'Mon–Sat, 8am–7pm WAT' },
                  { icon: Mail, label: 'Email', value: 'concierge@plusworld.ng', sub: 'Response within 2 hours' },
                  { icon: MapPin, label: 'Office', value: '15 Adeola Odeku Street', sub: 'Victoria Island, Lagos' },
                ].map((contact) => (
                  <div key={contact.label} className="flex items-start gap-4">
                    <div className="w-10 h-10 border border-[#144d3c]/15 flex items-center justify-center flex-shrink-0">
                      <contact.icon size={15} className="text-[#144d3c]/50" />
                    </div>
                    <div>
                      <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/30 font-['Inter'] mb-0.5">{contact.label}</div>
                      <div className="text-[#144d3c] font-['Inter'] text-sm font-medium">{contact.value}</div>
                      <div className="text-[#144d3c]/40 text-xs font-['Inter']">{contact.sub}</div>
                    </div>
                  </div>
                ))}
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={200}>
              <form className="space-y-5" onSubmit={(e) => { e.preventDefault(); onScheduleTour(); }}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Name</label>
                    <input type="text" className="w-full px-4 py-3 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors" placeholder="Your name" />
                  </div>
                  <div>
                    <label className="block text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Email</label>
                    <input type="email" className="w-full px-4 py-3 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors" placeholder="your@email.com" />
                  </div>
                </div>
                <div>
                  <label className="block text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Subject</label>
                  <input type="text" className="w-full px-4 py-3 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors" placeholder="Property enquiry / Investment / Valuation" />
                </div>
                <div>
                  <label className="block text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Message</label>
                  <textarea rows={5} className="w-full px-4 py-3 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] transition-colors resize-none" placeholder="Tell us about your requirements..." />
                </div>
                <button type="submit" className="w-full bg-[#144d3c] text-[#fbe7c5] py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-colors">
                  Send Message
                </button>
              </form>
            </AnimatedSection>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
