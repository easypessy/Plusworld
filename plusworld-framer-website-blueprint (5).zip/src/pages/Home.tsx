import React, { useEffect, useRef, useState } from 'react';
import { ArrowDown, Play, Award, MapPin, ChevronLeft, ChevronRight } from 'lucide-react';
import { properties, investorStats } from '../data/properties';
import PropertyCard from '../components/PropertyCard';
import AnimatedSection from '../components/AnimatedSection';
import { Property } from '../data/properties';

interface HomeProps {
  onScheduleTour: (title?: string) => void;
  onNavigate: (page: string) => void;
  onViewProperty: (property: Property) => void;
}

const Home: React.FC<HomeProps> = ({ onScheduleTour, onNavigate, onViewProperty }) => {
  const heroRef = useRef<HTMLDivElement>(null);
  const [heroOffset, setHeroOffset] = useState(0);
  const [currentSlide, setCurrentSlide] = useState(0);

  const featured = properties.filter(p => p.featured);

  // Parallax effect on hero
  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        setHeroOffset(window.scrollY * 0.4);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-advance slider
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % featured.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [featured.length]);

  const locations = [
    { name: 'Lekki', count: 12, desc: 'Phase 1 & 2 · Chevron · Ikate', growth: '+34% YoY' },
    { name: 'Victoria Island', count: 8, desc: 'Ahmadu Bello · Adeola Odeku · Kuramo', growth: '+28% YoY' },
    { name: 'Ibeju-Lekki', count: 15, desc: 'Dangote Axis · Eleko · Awoyaya', growth: '+52% YoY' },
  ];

  return (
    <div className="min-h-screen bg-[#fafaf8]">
      {/* ── HERO ── */}
      <section ref={heroRef} className="relative h-screen min-h-[700px] overflow-hidden flex items-center">
        {/* Parallax Background */}
        <div
          className="absolute inset-0 scale-110"
          style={{ transform: `translateY(${heroOffset}px) scale(1.1)` }}
        >
          <img
            src="/images/hero-bg.jpg"
            alt="Luxury property Lagos"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d3529]/85 via-[#0d3529]/50 to-[#0d3529]/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d3529]/60 via-transparent to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 w-full pt-20">
          <div className="max-w-2xl">
            <div className="flex items-center gap-3 mb-6 opacity-0 animate-[fadeUp_0.8s_0.3s_ease_forwards]">
              <div className="h-px w-12 bg-[#fbe7c5]/60" />
              <span className="text-[#fbe7c5]/70 text-[10px] tracking-[0.3em] uppercase font-['Inter']">
                Lagos · Nigeria · Est. 2018
              </span>
            </div>

            <h1 className="font-['Cormorant_Garamond'] text-white leading-[1.05] mb-6 opacity-0 animate-[fadeUp_0.8s_0.5s_ease_forwards]">
              <span className="block text-5xl lg:text-7xl font-light">Where Quiet</span>
              <span className="block text-5xl lg:text-7xl font-light italic text-[#fbe7c5]">Luxury</span>
              <span className="block text-5xl lg:text-7xl font-light">Finds Its Home</span>
            </h1>

            <p className="text-white/60 text-base lg:text-lg font-['Inter'] font-light max-w-md leading-relaxed mb-10 opacity-0 animate-[fadeUp_0.8s_0.7s_ease_forwards]">
              Premium real estate and investment opportunities across Lagos — Lekki, Victoria Island, and Ibeju-Lekki. For those who invest with vision.
            </p>

            <div className="flex flex-wrap gap-4 opacity-0 animate-[fadeUp_0.8s_0.9s_ease_forwards]">
              <button
                onClick={() => onNavigate('listings')}
                className="bg-[#fbe7c5] text-[#144d3c] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-white transition-all duration-300 hover:shadow-[0_8px_30px_rgba(251,231,197,0.4)]"
              >
                Explore Portfolio
              </button>
              <button
                onClick={() => onScheduleTour()}
                className="border border-[#fbe7c5]/40 text-[#fbe7c5] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:border-[#fbe7c5] hover:bg-[#fbe7c5]/10 transition-all duration-300"
              >
                Private Tour
              </button>
            </div>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-[#144d3c]/80 backdrop-blur-md border-t border-[#fbe7c5]/10">
          <div className="max-w-7xl mx-auto px-6 lg:px-10 py-5">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {investorStats.map((stat) => (
                <div key={stat.label} className="text-center lg:text-left">
                  <div className="text-[#fbe7c5] font-['Cormorant_Garamond'] text-2xl font-light">
                    {stat.value}
                  </div>
                  <div className="text-[#fbe7c5]/50 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mt-0.5">
                    {stat.sub}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-28 right-10 hidden lg:flex flex-col items-center gap-2 opacity-0 animate-[fadeIn_1s_1.5s_ease_forwards]">
          <span className="text-[#fbe7c5]/40 text-[9px] tracking-[0.25em] uppercase font-['Inter'] rotate-90 mb-8">
            Scroll
          </span>
          <ArrowDown size={14} className="text-[#fbe7c5]/40 animate-bounce" />
        </div>
      </section>

      {/* ── MARKET AUTHORITY ── */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <AnimatedSection animation="slideRight">
              <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-4">
                Lagos Market Authority
              </div>
              <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] leading-tight mb-6 font-light">
                Defining the Standard<br />
                <span className="italic text-[#144d3c]/60">for Premium Living</span>
              </h2>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light leading-relaxed mb-6 text-sm">
                Since 2018, Plusworld has curated the most prestigious real estate portfolio in Lagos — from waterfront estates in Ibeju-Lekki to sky-high penthouses on Victoria Island. We don't just sell properties; we architect legacies.
              </p>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light leading-relaxed mb-8 text-sm">
                With over ₦87 billion in managed assets and a 98% client satisfaction rate, our reputation speaks through results. Every listing is personally vetted, legally verified, and investment-graded by our team.
              </p>
              <div className="flex items-center gap-6">
                <button
                  onClick={() => onNavigate('about')}
                  className="text-[#144d3c] text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold border-b border-[#144d3c] pb-0.5 hover:text-[#144d3c]/60 transition-colors"
                >
                  Our Story
                </button>
                <button
                  onClick={() => onNavigate('investor')}
                  className="flex items-center gap-2 text-[#144d3c]/50 text-xs tracking-[0.15em] uppercase font-['Inter'] hover:text-[#144d3c] transition-colors"
                >
                  <Play size={12} className="fill-current" /> Investor Portal
                </button>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={200}>
              <div className="relative">
                <img
                  src="/images/about-bg.jpg"
                  alt="Lagos Skyline"
                  className="w-full h-80 object-cover"
                />
                <div className="absolute -bottom-6 -left-6 bg-[#144d3c] text-[#fbe7c5] p-6 w-52">
                  <div className="font-['Cormorant_Garamond'] text-3xl font-light mb-1">8 Years</div>
                  <div className="text-[#fbe7c5]/60 text-[9px] tracking-[0.2em] uppercase font-['Inter']">
                    of Excellence in Lagos
                  </div>
                </div>
                <div className="absolute -top-6 -right-6 bg-[#fbe7c5] p-5 w-44">
                  <div className="flex items-center gap-2 mb-1">
                    <Award size={14} className="text-[#144d3c]" />
                    <span className="text-[#144d3c] font-['Cormorant_Garamond'] text-lg">Award</span>
                  </div>
                  <div className="text-[#144d3c]/60 text-[8px] tracking-[0.15em] uppercase font-['Inter']">
                    Best Luxury Agency Nigeria 2025
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* ── FEATURED PROPERTIES SLIDER ── */}
      <section className="py-24 bg-[#fafaf8]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="flex items-end justify-between mb-12">
            <div>
              <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
                Featured Portfolio
              </div>
              <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] font-light">
                Exceptional Properties
              </h2>
            </div>
            <div className="hidden lg:flex items-center gap-3">
              <button
                onClick={() => setCurrentSlide(prev => (prev - 1 + featured.length) % featured.length)}
                className="w-10 h-10 border border-[#144d3c]/20 flex items-center justify-center text-[#144d3c]/60 hover:border-[#144d3c] hover:text-[#144d3c] transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                onClick={() => setCurrentSlide(prev => (prev + 1) % featured.length)}
                className="w-10 h-10 border border-[#144d3c]/20 flex items-center justify-center text-[#144d3c]/60 hover:border-[#144d3c] hover:text-[#144d3c] transition-colors"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </AnimatedSection>

          {/* Featured Slider */}
          <div className="relative overflow-hidden mb-6">
            <div
              className="flex transition-transform duration-700 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {featured.map((property) => (
                <div key={property.id} className="w-full flex-shrink-0">
                  <div className="grid lg:grid-cols-2 gap-0 bg-white shadow-[0_20px_60px_rgba(20,77,60,0.1)]">
                    <div className="relative h-72 lg:h-auto min-h-[400px] overflow-hidden">
                      <img
                        src={property.image}
                        alt={property.title}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#144d3c]/20" />
                      {property.verified && (
                        <div className="absolute top-4 left-4 bg-[#144d3c] text-[#fbe7c5] text-[9px] tracking-[0.2em] uppercase px-3 py-1.5 font-['Inter']">
                          Verified
                        </div>
                      )}
                    </div>
                    <div className="p-8 lg:p-12 flex flex-col justify-center">
                      <div className="text-[#144d3c]/40 text-[10px] tracking-[0.25em] uppercase font-['Inter'] mb-3 flex items-center gap-2">
                        <MapPin size={10} /> {property.location}
                      </div>
                      <h3 className="font-['Cormorant_Garamond'] text-3xl lg:text-4xl text-[#144d3c] font-light mb-2">
                        {property.title}
                      </h3>
                      <p className="text-[#144d3c]/50 italic font-['Cormorant_Garamond'] text-lg mb-4">
                        {property.tagline}
                      </p>
                      <p className="text-[#144d3c]/60 text-sm font-['Inter'] font-light leading-relaxed mb-6">
                        {property.description}
                      </p>
                      <div className="grid grid-cols-3 gap-4 mb-8 pb-8 border-b border-[#144d3c]/10">
                        {property.type !== 'Land' && (
                          <>
                            <div>
                              <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.bedrooms}</div>
                              <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Bedrooms</div>
                            </div>
                            <div>
                              <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.sqm.toLocaleString()}</div>
                              <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Sqm</div>
                            </div>
                          </>
                        )}
                        <div>
                          <div className="font-['Cormorant_Garamond'] text-2xl text-emerald-600">{property.roi}%</div>
                          <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Annual ROI</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-[#144d3c]/40 text-[9px] tracking-[0.15em] uppercase font-['Inter'] mb-1">Asking Price</div>
                          <div className="font-['Cormorant_Garamond'] text-3xl text-[#144d3c] font-light">{property.priceLabel}</div>
                        </div>
                        <div className="flex gap-3">
                          <button
                            onClick={() => onScheduleTour(property.title)}
                            className="bg-[#144d3c] text-[#fbe7c5] px-5 py-3 text-[9px] tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-colors"
                          >
                            Book Viewing
                          </button>
                          <button
                            onClick={() => onViewProperty(property)}
                            className="border border-[#144d3c]/20 text-[#144d3c] px-5 py-3 text-[9px] tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:border-[#144d3c] transition-colors"
                          >
                            Details
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Slider Dots */}
          <div className="flex justify-center gap-2">
            {featured.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentSlide(i)}
                className={`transition-all duration-300 ${i === currentSlide ? 'w-6 h-1.5 bg-[#144d3c]' : 'w-1.5 h-1.5 bg-[#144d3c]/20 rounded-full'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── ALL PROPERTIES GRID ── */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Our Listings
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] font-light mb-4">
              The Full Collection
            </h2>
            <div className="w-16 h-px bg-[#144d3c]/20 mx-auto" />
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property, i) => (
              <AnimatedSection key={property.id} animation="fadeUp" delay={i * 80}>
                <PropertyCard
                  property={property}
                  onView={onViewProperty}
                  onScheduleTour={(title) => onScheduleTour(title)}
                  index={i}
                />
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection className="text-center mt-12">
            <button
              onClick={() => onNavigate('listings')}
              className="inline-flex items-center gap-3 border border-[#144d3c] text-[#144d3c] px-10 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#144d3c] hover:text-[#fbe7c5] transition-all duration-300"
            >
              View All Listings
              <ArrowDown size={14} className="-rotate-90" />
            </button>
          </AnimatedSection>
        </div>
      </section>

      {/* ── LOCATIONS ── */}
      <section className="py-24 bg-[#144d3c]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Prime Locations
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#fbe7c5] font-light">
              Where We Operate
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-3 gap-6">
            {locations.map((loc, i) => (
              <AnimatedSection key={loc.name} animation="fadeUp" delay={i * 150}>
                <div
                  className="group border border-[#fbe7c5]/10 p-8 hover:border-[#fbe7c5]/30 hover:bg-[#fbe7c5]/5 transition-all duration-500 cursor-pointer"
                  onClick={() => onNavigate('listings')}
                >
                  <div className="flex items-start justify-between mb-6">
                    <MapPin size={20} className="text-[#fbe7c5]/40 mt-1" />
                    <span className="text-emerald-400 text-xs font-['Inter'] font-semibold">{loc.growth}</span>
                  </div>
                  <div className="font-['Cormorant_Garamond'] text-3xl text-[#fbe7c5] font-light mb-1">
                    {loc.name}
                  </div>
                  <div className="text-[#fbe7c5]/50 text-xs font-['Inter'] mb-5">{loc.desc}</div>
                  <div className="flex items-center justify-between border-t border-[#fbe7c5]/10 pt-5">
                    <span className="text-[#fbe7c5]/40 text-[10px] tracking-[0.15em] uppercase font-['Inter']">
                      {loc.count} Available
                    </span>
                    <ArrowDown size={14} className="text-[#fbe7c5]/40 -rotate-90 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ── INVESTOR TEASER ── */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute inset-0">
          <img src="/images/investor-bg.jpg" alt="Investment" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#0d1f1a]/75" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 text-center">
          <AnimatedSection>
            <div className="text-[#fbe7c5]/50 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-4">
              High-Net-Worth Investment
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-6xl text-white font-light mb-6 max-w-3xl mx-auto leading-tight">
              Nigeria's Most Lucrative<br />
              <span className="italic text-[#fbe7c5]">Real Estate Corridor</span>
            </h2>
            <p className="text-white/50 font-['Inter'] font-light text-base max-w-xl mx-auto mb-10">
              Access exclusive off-plan opportunities in Ibeju-Lekki — projected to yield 40%+ ROI over 3 years as Nigeria's new economic hub takes shape.
            </p>
            <div className="flex flex-wrap justify-center gap-10 mb-12">
              {[
                { v: '₦2.5T', l: 'Ibeju-Lekki Infrastructure Spend' },
                { v: '40%+', l: 'Projected 3-Year ROI' },
                { v: '500K+', l: 'New Jobs by 2028' },
              ].map(item => (
                <div key={item.l} className="text-center">
                  <div className="font-['Cormorant_Garamond'] text-4xl text-[#fbe7c5] font-light">{item.v}</div>
                  <div className="text-white/40 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mt-1 max-w-[140px]">{item.l}</div>
                </div>
              ))}
            </div>
            <button
              onClick={() => onNavigate('investor')}
              className="bg-[#fbe7c5] text-[#144d3c] px-10 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-white transition-all duration-300 hover:shadow-[0_8px_40px_rgba(251,231,197,0.3)]"
            >
              Access Investor Portal
            </button>
          </AnimatedSection>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 bg-[#fafaf8]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Client Voices
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light">
              What Our Clients Say
            </h2>
          </AnimatedSection>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                quote: "Plusworld found me a Lekki property that yielded 24% in just 18 months. Their market intelligence is unparalleled.",
                name: "Adebayo K.",
                role: "Private Equity Investor, Lagos",
                stars: 5,
              },
              {
                quote: "The team managed every detail of my Victoria Island penthouse purchase — from legal verification to interior finishing. Impeccable service.",
                name: "Dr. Ngozi A.",
                role: "CEO, Abuja",
                stars: 5,
              },
              {
                quote: "I invested in 3 plots in Ibeju-Lekki through Plusworld. Already up 38% and they haven't even started the development phase.",
                name: "Emeka O.",
                role: "Diaspora Investor, London",
                stars: 5,
              },
            ].map((t, i) => (
              <AnimatedSection key={i} animation="fadeUp" delay={i * 120}>
                <div className="bg-white p-8 border-l-2 border-[#144d3c] h-full flex flex-col">
                  <div className="flex gap-0.5 mb-4">
                    {Array.from({ length: t.stars }).map((_, j) => (
                      <span key={j} className="text-[#fbe7c5] text-sm">★</span>
                    ))}
                  </div>
                  <p className="text-[#144d3c]/70 font-['Cormorant_Garamond'] text-lg italic leading-relaxed flex-1 mb-6">
                    "{t.quote}"
                  </p>
                  <div>
                    <div className="font-['Inter'] font-semibold text-[#144d3c] text-sm">{t.name}</div>
                    <div className="text-[#144d3c]/40 text-xs font-['Inter'] mt-0.5">{t.role}</div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="py-20 bg-[#fbe7c5]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <AnimatedSection>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] font-light mb-4">
              Ready to Find Your<br />
              <span className="italic">Perfect Property?</span>
            </h2>
            <p className="text-[#144d3c]/60 font-['Inter'] font-light text-sm mb-8 max-w-md mx-auto">
              Let our luxury concierge team guide you through Lagos' finest real estate offerings.
            </p>
            <button
              onClick={() => onScheduleTour()}
              className="bg-[#144d3c] text-[#fbe7c5] px-10 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-all duration-300 hover:shadow-[0_8px_30px_rgba(20,77,60,0.3)]"
            >
              Schedule Private Consultation
            </button>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
};

export default Home;
