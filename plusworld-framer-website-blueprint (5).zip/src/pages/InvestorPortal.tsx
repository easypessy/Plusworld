import React, { useState } from 'react';
import { TrendingUp, Shield, BarChart3, Globe, ChevronDown, ArrowUpRight, Check } from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';

interface InvestorPortalProps {
  onScheduleTour: (title?: string) => void;
}

const InvestorPortal: React.FC<InvestorPortalProps> = ({ onScheduleTour }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const corridors = [
    {
      title: 'Ibeju-Lekki Corridor',
      roi: '40%+',
      horizon: '3 Years',
      min: '₦95M',
      tags: ['Dangote Refinery Proximity', 'Lekki Free Trade Zone', 'Deep Sea Port Access'],
      highlight: 'Fastest Appreciating Zone in West Africa',
      desc: 'Strategic land and early-stage developments adjacent to Africa\'s largest industrial complex. Government infrastructure spend exceeds ₦2.5 trillion.',
      tier: 'Ultra-Premium',
    },
    {
      title: 'Victoria Island Premium',
      roi: '22%',
      horizon: '2 Years',
      min: '₦380M',
      tags: ['Grade-A Commercial', 'Luxury Residential', 'Waterfront Access'],
      highlight: 'Lagos\'s Financial Capital',
      desc: 'Established investment zone with consistent rental yields from expatriate and corporate demand. Proven track record across economic cycles.',
      tier: 'Premium',
    },
    {
      title: 'Lekki Phase 1 & 2',
      roi: '18%',
      horizon: '18 Months',
      min: '₦200M',
      tags: ['Mid-Luxury Residential', 'High Rental Demand', 'Infrastructure Mature'],
      highlight: 'Steady, High-Liquidity Returns',
      desc: 'Lagos\' premier residential district offering the best risk-adjusted returns in Nigeria. Strong secondary market and consistent buyer demand.',
      tier: 'High',
    },
  ];

  const faqs = [
    {
      q: 'How does Plusworld verify property titles?',
      a: 'Every listing undergoes a rigorous 5-step legal verification process: deed of assignment review, survey plan validation, land registry search, governor\'s consent confirmation, and independent legal opinion. Our verified badge means zero title risk.',
    },
    {
      q: 'Can diaspora Nigerians invest remotely?',
      a: 'Absolutely. We have a dedicated diaspora investment team that manages the entire transaction — from virtual property tours, notarized power of attorney, international wire processing, to delivery of title documents. Over 35% of our clients invest from abroad.',
    },
    {
      q: 'What is the minimum investment for the Ibeju-Lekki corridor?',
      a: 'Land plots start from ₦95M for 500m². We also offer fractional investment opportunities from ₦25M through our syndicated property fund, allowing investors to benefit from appreciation without full property ownership.',
    },
    {
      q: 'How are rental yields calculated and distributed?',
      a: 'Rental projections are based on our proprietary Lagos Rental Intelligence data — updated quarterly. For managed properties, rental income is distributed monthly, net of 8% management fees. Our average achieved yield is 12-15% per annum.',
    },
    {
      q: 'What legal protections do investors have?',
      a: 'All investments are protected by a full Purchase Agreement under Nigerian property law, registered at the Lands Registry. We provide a 12-month defect liability period on new constructions, and mandatory title insurance on all land transactions.',
    },
  ];

  const tierMap: Record<string, string> = {
    'Ultra-Premium': 'bg-[#fbe7c5] text-[#144d3c]',
    'Premium': 'bg-[#144d3c] text-[#fbe7c5]',
    'High': 'bg-slate-100 text-slate-700',
  };

  return (
    <div className="min-h-screen bg-[#fafaf8] pt-20">
      {/* Hero */}
      <div className="relative min-h-[70vh] flex items-center overflow-hidden bg-[#0d1f1a]">
        <div className="absolute inset-0">
          <img src="/images/investor-bg.jpg" alt="Investor Portal" className="w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d1f1a]/90 via-[#0d1f1a]/60 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 py-20">
          <AnimatedSection>
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-10 bg-[#fbe7c5]/40" />
              <span className="text-[#fbe7c5]/50 text-[10px] tracking-[0.3em] uppercase font-['Inter']">
                Private Client Portal
              </span>
            </div>
            <h1 className="font-['Cormorant_Garamond'] text-4xl lg:text-7xl text-white font-light leading-[1.05] max-w-2xl mb-6">
              Invest Where<br />
              <span className="italic text-[#fbe7c5]">Africa Grows</span>
            </h1>
            <p className="text-white/50 font-['Inter'] font-light text-base max-w-lg leading-relaxed mb-10">
              Exclusive access to Nigeria's highest-yielding real estate opportunities. Curated for high-net-worth investors seeking capital preservation and superior returns.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => onScheduleTour('Investor Consultation')}
                className="bg-[#fbe7c5] text-[#144d3c] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-white transition-all duration-300"
              >
                Request Investment Brief
              </button>
              <button
                className="border border-[#fbe7c5]/30 text-[#fbe7c5] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:border-[#fbe7c5]/60 transition-colors"
              >
                Download Market Report
              </button>
            </div>
          </AnimatedSection>
        </div>

        {/* Floating ROI Card */}
        <div className="absolute bottom-10 right-10 hidden lg:block">
          <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 w-56">
            <div className="text-[#fbe7c5]/60 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-2">
              Portfolio Performance
            </div>
            <div className="font-['Cormorant_Garamond'] text-4xl text-[#fbe7c5] font-light mb-1">22.4%</div>
            <div className="text-white/40 text-xs font-['Inter']">Average Annual ROI</div>
            <div className="mt-4 pt-4 border-t border-white/10 flex items-center gap-2">
              <TrendingUp size={12} className="text-emerald-400" />
              <span className="text-emerald-400 text-xs font-['Inter']">+8.2% vs market avg.</span>
            </div>
          </div>
        </div>
      </div>

      {/* Investment Pillars */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Our Investment Philosophy
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] font-light">
              Why Nigeria. Why Now.
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: TrendingUp,
                title: 'Superior Yields',
                desc: 'Lagos prime real estate consistently delivers 18-42% annual returns — outperforming global luxury markets by 2-3x.',
              },
              {
                icon: Shield,
                title: 'Legal Certainty',
                desc: 'Every investment is backed by registered C of O title, independent legal verification, and mandatory title insurance.',
              },
              {
                icon: BarChart3,
                title: 'Data-Driven Picks',
                desc: 'Our Lagos Rental Intelligence platform tracks 10,000+ data points to identify properties with optimal appreciation potential.',
              },
              {
                icon: Globe,
                title: 'Diaspora Ready',
                desc: 'Full remote investment services — virtual tours, international wire processing, and document delivery anywhere in the world.',
              },
            ].map((pillar, i) => (
              <AnimatedSection key={pillar.title} animation="fadeUp" delay={i * 100}>
                <div className="p-8 border border-[#144d3c]/8 hover:border-[#144d3c]/20 hover:shadow-[0_20px_50px_rgba(20,77,60,0.08)] transition-all duration-500 h-full">
                  <pillar.icon size={24} className="text-[#144d3c]/40 mb-6" strokeWidth={1.5} />
                  <h3 className="font-['Cormorant_Garamond'] text-xl text-[#144d3c] mb-3">{pillar.title}</h3>
                  <p className="text-[#144d3c]/50 text-sm font-['Inter'] font-light leading-relaxed">{pillar.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Investment Corridors */}
      <section className="py-24 bg-[#fafaf8]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Opportunity Map
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl lg:text-5xl text-[#144d3c] font-light">
              Investment Corridors
            </h2>
          </AnimatedSection>

          <div className="space-y-6">
            {corridors.map((corridor, i) => (
              <AnimatedSection key={corridor.title} animation="slideRight" delay={i * 120}>
                <div className="bg-white border border-[#144d3c]/8 hover:border-[#144d3c]/20 hover:shadow-[0_20px_60px_rgba(20,77,60,0.08)] transition-all duration-500 overflow-hidden">
                  <div className="p-8 lg:p-10 grid lg:grid-cols-4 gap-8 items-center">
                    {/* Info */}
                    <div className="lg:col-span-2">
                      <div className="flex items-center gap-3 mb-4">
                        <span className={`text-[9px] tracking-[0.2em] uppercase px-2.5 py-1 font-['Inter'] font-semibold ${tierMap[corridor.tier]}`}>
                          {corridor.tier}
                        </span>
                        <span className="text-emerald-600 text-xs font-['Inter'] font-semibold">{corridor.highlight}</span>
                      </div>
                      <h3 className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c] mb-3">{corridor.title}</h3>
                      <p className="text-[#144d3c]/50 text-sm font-['Inter'] font-light leading-relaxed mb-5">{corridor.desc}</p>
                      <div className="flex flex-wrap gap-2">
                        {corridor.tags.map(tag => (
                          <span key={tag} className="flex items-center gap-1.5 text-[9px] tracking-[0.1em] uppercase text-[#144d3c]/50 font-['Inter']">
                            <Check size={9} className="text-[#144d3c]/30" /> {tag}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 lg:grid-cols-1 gap-4 lg:gap-6 border-l border-[#144d3c]/8 lg:pl-8">
                      <div>
                        <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/30 font-['Inter'] mb-1">Projected ROI</div>
                        <div className="font-['Cormorant_Garamond'] text-3xl text-emerald-600 font-light">{corridor.roi}</div>
                      </div>
                      <div>
                        <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/30 font-['Inter'] mb-1">Investment Horizon</div>
                        <div className="font-['Cormorant_Garamond'] text-3xl text-[#144d3c] font-light">{corridor.horizon}</div>
                      </div>
                      <div>
                        <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/30 font-['Inter'] mb-1">Entry From</div>
                        <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c] font-light">{corridor.min}</div>
                      </div>
                    </div>

                    {/* CTA */}
                    <div className="flex flex-col gap-3 lg:border-l border-[#144d3c]/8 lg:pl-8">
                      <button
                        onClick={() => onScheduleTour(`${corridor.title} Investment`)}
                        className="flex items-center justify-between w-full bg-[#144d3c] text-[#fbe7c5] px-5 py-3.5 text-[9px] tracking-[0.18em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-colors"
                      >
                        Get Investment Brief
                        <ArrowUpRight size={14} />
                      </button>
                      <button className="flex items-center justify-between w-full border border-[#144d3c]/20 text-[#144d3c] px-5 py-3.5 text-[9px] tracking-[0.18em] uppercase font-['Inter'] font-semibold hover:border-[#144d3c] transition-colors">
                        View Properties
                        <ArrowUpRight size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Diaspora Section */}
      <section className="py-24 bg-[#144d3c]">
        <div className="max-w-7xl mx-auto px-6 lg:px-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <AnimatedSection animation="slideRight">
              <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-4">
                Diaspora Investment Program
              </div>
              <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#fbe7c5] font-light mb-6 leading-tight">
                Invest in Nigeria<br />
                <span className="italic text-[#fbe7c5]/70">From Anywhere in the World</span>
              </h2>
              <p className="text-[#fbe7c5]/50 font-['Inter'] font-light leading-relaxed mb-8 text-sm">
                Over 35% of our clients are Nigerians in the diaspora building wealth at home. We handle every aspect — from legal verification to key handover — while you're abroad.
              </p>
              <div className="space-y-4">
                {[
                  'Virtual 4K property tours with live Q&A',
                  'Notarized Power of Attorney processing',
                  'International wire transfer & FX support',
                  'Dedicated diaspora relationship manager',
                  'Property management & rental income remittance',
                  'Annual investment performance reporting',
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#fbe7c5]/10 flex items-center justify-center flex-shrink-0">
                      <Check size={10} className="text-[#fbe7c5]" />
                    </div>
                    <span className="text-[#fbe7c5]/60 text-sm font-['Inter'] font-light">{item}</span>
                  </div>
                ))}
              </div>
              <button
                onClick={() => onScheduleTour('Diaspora Investment Program')}
                className="mt-10 bg-[#fbe7c5] text-[#144d3c] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-white transition-all duration-300 inline-block"
              >
                Schedule Diaspora Consultation
              </button>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" delay={200}>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { flag: '🇬🇧', city: 'London', clients: '142 Clients' },
                  { flag: '🇺🇸', city: 'Houston', clients: '98 Clients' },
                  { flag: '🇨🇦', city: 'Toronto', clients: '67 Clients' },
                  { flag: '🇦🇪', city: 'Dubai', clients: '89 Clients' },
                ].map((loc) => (
                  <div key={loc.city} className="bg-[#fbe7c5]/5 border border-[#fbe7c5]/10 p-6 hover:bg-[#fbe7c5]/10 transition-colors">
                    <div className="text-3xl mb-3">{loc.flag}</div>
                    <div className="font-['Cormorant_Garamond'] text-xl text-[#fbe7c5] mb-1">{loc.city}</div>
                    <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.15em] uppercase font-['Inter']">{loc.clients}</div>
                  </div>
                ))}
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-white">
        <div className="max-w-3xl mx-auto px-6 lg:px-10">
          <AnimatedSection className="text-center mb-16">
            <div className="text-[#144d3c]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Investor FAQ
            </div>
            <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light">
              Common Questions
            </h2>
          </AnimatedSection>

          <div className="divide-y divide-[#144d3c]/8">
            {faqs.map((faq, i) => (
              <AnimatedSection key={i} animation="fadeUp" delay={i * 60}>
                <div>
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full text-left py-6 flex items-center justify-between gap-4 group"
                  >
                    <span className="font-['Cormorant_Garamond'] text-lg text-[#144d3c] group-hover:text-[#144d3c]/70 transition-colors">
                      {faq.q}
                    </span>
                    <ChevronDown
                      size={16}
                      className={`text-[#144d3c]/40 flex-shrink-0 transition-transform duration-300 ${openFaq === i ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {openFaq === i && (
                    <div className="pb-6 text-[#144d3c]/60 text-sm font-['Inter'] font-light leading-relaxed">
                      {faq.a}
                    </div>
                  )}
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <div className="bg-[#fbe7c5] py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <AnimatedSection>
            <h2 className="font-['Cormorant_Garamond'] text-4xl text-[#144d3c] font-light mb-4">
              Ready to Build Your<br />
              <span className="italic">Lagos Real Estate Portfolio?</span>
            </h2>
            <p className="text-[#144d3c]/60 text-sm font-['Inter'] font-light mb-8 max-w-md mx-auto">
              Speak with a senior investment advisor — no obligation, complete discretion.
            </p>
            <button
              onClick={() => onScheduleTour('Investment Portfolio Consultation')}
              className="bg-[#144d3c] text-[#fbe7c5] px-10 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-all duration-300"
            >
              Schedule Private Consultation
            </button>
          </AnimatedSection>
        </div>
      </div>
    </div>
  );
};

export default InvestorPortal;
