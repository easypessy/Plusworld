import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, TrendingUp } from 'lucide-react';
import { properties, Property, PropertyType, LocationType } from '../data/properties';
import PropertyCard from '../components/PropertyCard';
import AnimatedSection from '../components/AnimatedSection';

interface ListingsProps {
  onScheduleTour: (title?: string) => void;
  onViewProperty: (property: Property) => void;
}

type SortOption = 'price-asc' | 'price-desc' | 'roi-desc' | 'newest';

const Listings: React.FC<ListingsProps> = ({ onScheduleTour, onViewProperty }) => {
  const [search, setSearch] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<LocationType | 'All'>('All');
  const [selectedType, setSelectedType] = useState<PropertyType | 'All'>('All');
  const [selectedTier, setSelectedTier] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortOption>('roi-desc');
  const [showFilters, setShowFilters] = useState(false);

  const locations: (LocationType | 'All')[] = ['All', 'Lekki', 'Victoria Island', 'Ibeju-Lekki'];
  const types: (PropertyType | 'All')[] = ['All', 'Villa', 'Penthouse', 'Duplex', 'Estate', 'Townhouse', 'Land'];
  const tiers = ['All', 'Premium', 'High', 'Medium'];

  const filtered = useMemo(() => {
    let result = [...properties];

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.address.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q)
      );
    }
    if (selectedLocation !== 'All') result = result.filter(p => p.location === selectedLocation);
    if (selectedType !== 'All') result = result.filter(p => p.type === selectedType);
    if (selectedTier !== 'All') result = result.filter(p => p.investmentTier === selectedTier);

    result.sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'roi-desc') return b.roi - a.roi;
      if (sortBy === 'newest') return b.yearBuilt - a.yearBuilt;
      return 0;
    });

    return result;
  }, [search, selectedLocation, selectedType, selectedTier, sortBy]);

  const activeFilters = [
    selectedLocation !== 'All' && selectedLocation,
    selectedType !== 'All' && selectedType,
    selectedTier !== 'All' && selectedTier,
  ].filter(Boolean) as string[];

  const clearFilters = () => {
    setSelectedLocation('All');
    setSelectedType('All');
    setSelectedTier('All');
    setSearch('');
  };

  return (
    <div className="min-h-screen bg-[#fafaf8] pt-20">
      {/* Hero Banner */}
      <div className="bg-[#144d3c] py-20 px-6 lg:px-10 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: 'repeating-linear-gradient(45deg, #fbe7c5 0, #fbe7c5 1px, transparent 0, transparent 50%)',
            backgroundSize: '20px 20px',
          }} />
        </div>
        <div className="max-w-7xl mx-auto relative z-10">
          <AnimatedSection>
            <div className="text-[#fbe7c5]/40 text-[10px] tracking-[0.3em] uppercase font-['Inter'] mb-3">
              Complete Portfolio
            </div>
            <h1 className="font-['Cormorant_Garamond'] text-4xl lg:text-6xl text-[#fbe7c5] font-light mb-4">
              All Properties
            </h1>
            <p className="text-[#fbe7c5]/50 font-['Inter'] font-light text-sm max-w-md">
              Browse our curated selection of premium properties across Lagos' most sought-after addresses.
            </p>
          </AnimatedSection>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="sticky top-20 z-30 bg-white border-b border-[#144d3c]/8 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-4">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 min-w-48 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#144d3c]/30" />
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search properties..."
                className="w-full pl-9 pr-4 py-2.5 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-sm font-['Inter'] placeholder:text-[#144d3c]/30 transition-colors"
              />
            </div>

            {/* Location Filter */}
            <div className="hidden md:flex items-center gap-1">
              {locations.map(loc => (
                <button
                  key={loc}
                  onClick={() => setSelectedLocation(loc)}
                  className={`px-3 py-2 text-[10px] tracking-[0.15em] uppercase font-['Inter'] transition-all duration-200 ${
                    selectedLocation === loc
                      ? 'bg-[#144d3c] text-[#fbe7c5]'
                      : 'text-[#144d3c]/50 hover:text-[#144d3c]'
                  }`}
                >
                  {loc}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 ml-auto">
              {/* Sort */}
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as SortOption)}
                className="py-2.5 px-3 bg-[#fafaf8] border border-[#144d3c]/15 focus:border-[#144d3c] outline-none text-[#144d3c] text-xs font-['Inter'] appearance-none cursor-pointer"
              >
                <option value="roi-desc">Highest ROI</option>
                <option value="price-asc">Price: Low–High</option>
                <option value="price-desc">Price: High–Low</option>
                <option value="newest">Newest First</option>
              </select>

              {/* Filters Toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center gap-2 py-2.5 px-4 border text-xs tracking-[0.1em] uppercase font-['Inter'] transition-colors ${
                  showFilters
                    ? 'bg-[#144d3c] text-[#fbe7c5] border-[#144d3c]'
                    : 'border-[#144d3c]/20 text-[#144d3c]/60 hover:border-[#144d3c] hover:text-[#144d3c]'
                }`}
              >
                <SlidersHorizontal size={13} />
                Filters
                {activeFilters.length > 0 && (
                  <span className="bg-[#fbe7c5] text-[#144d3c] rounded-full w-4 h-4 text-[9px] flex items-center justify-center font-semibold">
                    {activeFilters.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Extended Filters */}
          {showFilters && (
            <div className="pt-4 mt-4 border-t border-[#144d3c]/8 flex flex-wrap gap-6">
              {/* Type */}
              <div>
                <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Type</div>
                <div className="flex flex-wrap gap-1">
                  {types.map(type => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className={`px-3 py-1.5 text-[9px] tracking-[0.12em] uppercase font-['Inter'] border transition-all ${
                        selectedType === type
                          ? 'bg-[#144d3c] text-[#fbe7c5] border-[#144d3c]'
                          : 'border-[#144d3c]/15 text-[#144d3c]/50 hover:border-[#144d3c]/40'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Investment Tier */}
              <div>
                <div className="text-[9px] tracking-[0.2em] uppercase text-[#144d3c]/40 font-['Inter'] mb-2">Investment Tier</div>
                <div className="flex gap-1">
                  {tiers.map(tier => (
                    <button
                      key={tier}
                      onClick={() => setSelectedTier(tier)}
                      className={`px-3 py-1.5 text-[9px] tracking-[0.12em] uppercase font-['Inter'] border transition-all ${
                        selectedTier === tier
                          ? 'bg-[#144d3c] text-[#fbe7c5] border-[#144d3c]'
                          : 'border-[#144d3c]/15 text-[#144d3c]/50 hover:border-[#144d3c]/40'
                      }`}
                    >
                      {tier}
                    </button>
                  ))}
                </div>
              </div>

              {activeFilters.length > 0 && (
                <button
                  onClick={clearFilters}
                  className="flex items-center gap-1.5 text-[9px] tracking-[0.15em] uppercase font-['Inter'] text-red-400 hover:text-red-600 transition-colors self-end mb-1"
                >
                  <X size={10} /> Clear All
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Active Filter Pills */}
      {activeFilters.length > 0 && (
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-4 flex flex-wrap gap-2">
          {activeFilters.map(filter => (
            <span key={filter} className="flex items-center gap-2 bg-[#144d3c]/8 text-[#144d3c] text-[9px] tracking-[0.15em] uppercase px-3 py-1.5 font-['Inter']">
              {filter}
            </span>
          ))}
        </div>
      )}

      {/* Results */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-10">
        <div className="flex items-center justify-between mb-8">
          <div className="text-[#144d3c]/50 text-sm font-['Inter']">
            <span className="text-[#144d3c] font-semibold">{filtered.length}</span> properties found
          </div>
          <div className="flex items-center gap-2 text-[#144d3c]/40 text-xs font-['Inter']">
            <TrendingUp size={12} />
            Sorted by {sortBy === 'roi-desc' ? 'ROI' : sortBy === 'price-asc' ? 'Price ↑' : sortBy === 'price-desc' ? 'Price ↓' : 'Newest'}
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((property, i) => (
              <AnimatedSection key={property.id} animation="fadeUp" delay={i * 60}>
                <PropertyCard
                  property={property}
                  onView={onViewProperty}
                  onScheduleTour={(title) => onScheduleTour(title)}
                  index={i}
                />
              </AnimatedSection>
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]/40 mb-3">No Properties Found</div>
            <p className="text-[#144d3c]/30 text-sm font-['Inter'] mb-6">Try adjusting your search filters</p>
            <button onClick={clearFilters} className="text-[#144d3c] text-xs tracking-[0.2em] uppercase font-['Inter'] border-b border-[#144d3c]/30 pb-0.5">
              Clear Filters
            </button>
          </div>
        )}
      </div>

      {/* Investment CTA */}
      <div className="bg-[#fbe7c5] py-16 mt-10">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h3 className="font-['Cormorant_Garamond'] text-3xl text-[#144d3c] font-light mb-3">
            Don't See What You're Looking For?
          </h3>
          <p className="text-[#144d3c]/60 text-sm font-['Inter'] font-light mb-6">
            We have off-market listings available exclusively to registered clients. Speak to our concierge team.
          </p>
          <button
            onClick={() => onScheduleTour()}
            className="bg-[#144d3c] text-[#fbe7c5] px-8 py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-colors"
          >
            Access Off-Market Listings
          </button>
        </div>
      </div>
    </div>
  );
};

export default Listings;
