import React, { useState } from 'react';
import { ArrowLeft, Bed, Bath, Square, TrendingUp, Shield, MapPin, Calendar, Check, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Property } from '../data/properties';
import AnimatedSection from '../components/AnimatedSection';

interface PropertyDetailProps {
  property: Property;
  onBack: () => void;
  onScheduleTour: (title?: string) => void;
}

const PropertyDetail: React.FC<PropertyDetailProps> = ({ property, onBack, onScheduleTour }) => {
  const [activeImage, setActiveImage] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const allImages = [property.image, ...property.galleryImages.filter(img => img !== property.image)];

  return (
    <div className="min-h-screen bg-[#fafaf8] pt-20">
      {/* Back Bar */}
      <div className="bg-white border-b border-[#144d3c]/8 sticky top-20 z-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-4 flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-[#144d3c]/60 hover:text-[#144d3c] text-xs tracking-[0.15em] uppercase font-['Inter'] transition-colors"
          >
            <ArrowLeft size={14} />
            Back to Listings
          </button>
          <div className="flex items-center gap-3">
            {property.verified && (
              <span className="flex items-center gap-1.5 bg-[#144d3c] text-[#fbe7c5] text-[9px] tracking-[0.2em] uppercase px-2.5 py-1.5 font-['Inter']">
                <Shield size={9} /> Verified
              </span>
            )}
            <span className="text-[#144d3c]/40 text-[9px] tracking-[0.15em] uppercase font-['Inter']">
              Ref: {property.id.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* Gallery */}
      <div className="relative bg-[#0d3529]">
        {/* Main Image */}
        <div
          className="relative h-72 lg:h-[560px] cursor-pointer overflow-hidden"
          onClick={() => setLightboxOpen(true)}
        >
          <img
            src={allImages[activeImage]}
            alt={property.title}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute bottom-6 right-6 bg-black/50 backdrop-blur-sm text-white text-[10px] tracking-[0.2em] uppercase px-3 py-1.5 font-['Inter']">
            {activeImage + 1} / {allImages.length} · Click to Expand
          </div>
          {allImages.length > 1 && (
            <>
              <button
                onClick={(e) => { e.stopPropagation(); setActiveImage(prev => (prev - 1 + allImages.length) % allImages.length); }}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/40 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/60 transition-colors"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); setActiveImage(prev => (prev + 1) % allImages.length); }}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/40 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/60 transition-colors"
              >
                <ChevronRight size={18} />
              </button>
            </>
          )}
        </div>

        {/* Thumbnails */}
        <div className="flex gap-2 p-4 overflow-x-auto">
          {allImages.map((img, i) => (
            <button
              key={i}
              onClick={() => setActiveImage(i)}
              className={`flex-shrink-0 w-20 h-14 overflow-hidden transition-all duration-200 ${
                activeImage === i ? 'ring-2 ring-[#fbe7c5] opacity-100' : 'opacity-50 hover:opacity-80'
              }`}
            >
              <img src={img} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>

      {/* Detail Body */}
      <div className="max-w-7xl mx-auto px-6 lg:px-10 py-12">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Left: Property Info */}
          <div className="lg:col-span-2 space-y-10">
            {/* Header */}
            <AnimatedSection>
              <div className="flex items-center gap-2 text-[#144d3c]/40 text-[10px] tracking-[0.2em] uppercase font-['Inter'] mb-3">
                <MapPin size={10} /> {property.address}
              </div>
              <h1 className="font-['Cormorant_Garamond'] text-3xl lg:text-5xl text-[#144d3c] font-light mb-2">
                {property.title}
              </h1>
              <p className="text-[#144d3c]/50 font-['Cormorant_Garamond'] text-xl italic mb-4">
                {property.tagline}
              </p>
              <p className="text-[#144d3c]/60 font-['Inter'] font-light text-sm leading-relaxed">
                {property.description}
              </p>
            </AnimatedSection>

            {/* Quick Stats */}
            <AnimatedSection animation="fadeUp" delay={100}>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 bg-white border border-[#144d3c]/8">
                {property.type !== 'Land' && (
                  <>
                    <div className="text-center">
                      <Bed size={18} className="text-[#144d3c]/30 mx-auto mb-2" />
                      <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.bedrooms}</div>
                      <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Bedrooms</div>
                    </div>
                    <div className="text-center">
                      <Bath size={18} className="text-[#144d3c]/30 mx-auto mb-2" />
                      <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.bathrooms}</div>
                      <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Bathrooms</div>
                    </div>
                  </>
                )}
                <div className="text-center">
                  <Square size={18} className="text-[#144d3c]/30 mx-auto mb-2" />
                  <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.sqm.toLocaleString()}</div>
                  <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Sqm</div>
                </div>
                <div className="text-center">
                  <TrendingUp size={18} className="text-emerald-500 mx-auto mb-2" />
                  <div className="font-['Cormorant_Garamond'] text-2xl text-emerald-600">{property.roi}%</div>
                  <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Annual ROI</div>
                </div>
                <div className="text-center">
                  <Calendar size={18} className="text-[#144d3c]/30 mx-auto mb-2" />
                  <div className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c]">{property.yearBuilt}</div>
                  <div className="text-[9px] tracking-[0.15em] uppercase text-[#144d3c]/40 font-['Inter']">Year Built</div>
                </div>
              </div>
            </AnimatedSection>

            {/* Amenities */}
            <AnimatedSection animation="fadeUp" delay={150}>
              <h3 className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c] mb-5">
                Features & Amenities
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {property.amenities.map((amenity) => (
                  <div key={amenity} className="flex items-center gap-2.5 p-3 bg-white border border-[#144d3c]/8 group hover:border-[#144d3c]/20 transition-colors">
                    <div className="w-5 h-5 rounded-full bg-[#144d3c]/5 flex items-center justify-center flex-shrink-0">
                      <Check size={10} className="text-[#144d3c]/60" />
                    </div>
                    <span className="text-[#144d3c]/70 text-xs font-['Inter']">{amenity}</span>
                  </div>
                ))}
              </div>
            </AnimatedSection>

            {/* Investment Breakdown */}
            <AnimatedSection animation="fadeUp" delay={200}>
              <h3 className="font-['Cormorant_Garamond'] text-2xl text-[#144d3c] mb-5">
                Investment Analysis
              </h3>
              <div className="bg-[#144d3c] p-8">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  <div>
                    <div className="text-[#fbe7c5]/40 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-1">Asset Value</div>
                    <div className="font-['Cormorant_Garamond'] text-3xl text-[#fbe7c5] font-light">{property.priceLabel}</div>
                  </div>
                  <div>
                    <div className="text-[#fbe7c5]/40 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-1">Annual ROI</div>
                    <div className="font-['Cormorant_Garamond'] text-3xl text-emerald-400 font-light">{property.roi}%</div>
                  </div>
                  <div>
                    <div className="text-[#fbe7c5]/40 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-1">Investment Grade</div>
                    <div className="font-['Cormorant_Garamond'] text-3xl text-[#fbe7c5] font-light">{property.investmentTier}</div>
                  </div>
                </div>
                <div className="mt-6 pt-6 border-t border-[#fbe7c5]/10">
                  <div className="text-[#fbe7c5]/50 text-xs font-['Inter'] font-light leading-relaxed">
                    * ROI projections based on Plusworld Lagos Rental Intelligence data. Past performance does not guarantee future returns. 
                    All figures subject to market conditions and legal verification.
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>

          {/* Right: Sticky Sidebar */}
          <div>
            <div className="sticky top-40">
              <AnimatedSection animation="slideLeft">
                <div className="bg-white border border-[#144d3c]/10 shadow-[0_20px_60px_rgba(20,77,60,0.08)] overflow-hidden">
                  {/* Price Header */}
                  <div className="bg-[#144d3c] p-6">
                    <div className="text-[#fbe7c5]/40 text-[9px] tracking-[0.2em] uppercase font-['Inter'] mb-1">Asking Price</div>
                    <div className="font-['Cormorant_Garamond'] text-4xl text-[#fbe7c5] font-light">{property.priceLabel}</div>
                    <div className="flex items-center gap-2 mt-2">
                      <TrendingUp size={12} className="text-emerald-400" />
                      <span className="text-emerald-400 text-xs font-['Inter']">{property.roi}% projected ROI</span>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="p-6 space-y-3 border-b border-[#144d3c]/8">
                    {[
                      ['Location', property.location],
                      ['Type', property.type],
                      ['Status', property.status],
                      ['Listed', `${property.yearBuilt}`],
                    ].map(([label, value]) => (
                      <div key={label} className="flex items-center justify-between">
                        <span className="text-[#144d3c]/40 text-xs font-['Inter']">{label}</span>
                        <span className="text-[#144d3c] text-xs font-['Inter'] font-medium">{value}</span>
                      </div>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="p-6 space-y-3">
                    <button
                      onClick={() => onScheduleTour(property.title)}
                      className="w-full bg-[#144d3c] text-[#fbe7c5] py-4 text-xs tracking-[0.2em] uppercase font-['Inter'] font-semibold hover:bg-[#1a6650] transition-colors"
                    >
                      Schedule Private Viewing
                    </button>
                    <button
                      onClick={() => onScheduleTour(property.title)}
                      className="w-full border border-[#144d3c]/20 text-[#144d3c] py-3.5 text-xs tracking-[0.15em] uppercase font-['Inter'] font-semibold hover:border-[#144d3c] transition-colors"
                    >
                      Request Investment Brief
                    </button>
                    <a
                      href="tel:+2348000000000"
                      className="flex items-center justify-center w-full border border-[#144d3c]/10 text-[#144d3c]/60 py-3 text-xs tracking-[0.12em] uppercase font-['Inter'] hover:text-[#144d3c] transition-colors"
                    >
                      Call +234 800 000 0000
                    </a>
                  </div>

                  {/* Concierge Note */}
                  <div className="px-6 pb-6">
                    <p className="text-center text-[9px] text-[#144d3c]/30 font-['Inter'] tracking-wide">
                      🔒 Your enquiry is strictly private & confidential
                    </p>
                  </div>
                </div>
              </AnimatedSection>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div
          className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-4"
          onClick={() => setLightboxOpen(false)}
        >
          <button
            className="absolute top-6 right-6 text-white/60 hover:text-white p-2"
            onClick={() => setLightboxOpen(false)}
          >
            <X size={24} />
          </button>
          <button
            className="absolute left-6 top-1/2 -translate-y-1/2 text-white/60 hover:text-white p-2"
            onClick={(e) => { e.stopPropagation(); setActiveImage(prev => (prev - 1 + allImages.length) % allImages.length); }}
          >
            <ChevronLeft size={30} />
          </button>
          <img
            src={allImages[activeImage]}
            alt={property.title}
            className="max-w-full max-h-[90vh] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            className="absolute right-6 top-1/2 -translate-y-1/2 text-white/60 hover:text-white p-2"
            onClick={(e) => { e.stopPropagation(); setActiveImage(prev => (prev + 1) % allImages.length); }}
          >
            <ChevronRight size={30} />
          </button>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            {allImages.map((_, i) => (
              <button
                key={i}
                onClick={(e) => { e.stopPropagation(); setActiveImage(i); }}
                className={`w-1.5 h-1.5 rounded-full transition-all ${i === activeImage ? 'bg-white w-4' : 'bg-white/30'}`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyDetail;
