export type PropertyType = 'Villa' | 'Penthouse' | 'Duplex' | 'Estate' | 'Townhouse' | 'Land';
export type LocationType = 'Lekki' | 'Victoria Island' | 'Ibeju-Lekki';
export type InvestmentTier = 'High' | 'Medium' | 'Premium';

export interface Property {
  id: string;
  title: string;
  tagline: string;
  location: LocationType;
  address: string;
  price: number;
  priceLabel: string;
  type: PropertyType;
  verified: boolean;
  featured: boolean;
  bedrooms: number;
  bathrooms: number;
  sqm: number;
  roi: number;
  investmentTier: InvestmentTier;
  image: string;
  galleryImages: string[];
  videoUrl?: string;
  amenities: string[];
  description: string;
  yearBuilt: number;
  status: 'Available' | 'Under Offer' | 'Sold';
}

export const properties: Property[] = [
  {
    id: 'pw-001',
    title: 'The Meridian Residence',
    tagline: 'Where Serenity Meets the Horizon',
    location: 'Lekki',
    address: 'Lekki Phase 1, Lagos',
    price: 850000000,
    priceLabel: '₦850M',
    type: 'Villa',
    verified: true,
    featured: true,
    bedrooms: 6,
    bathrooms: 7,
    sqm: 1200,
    roi: 18.4,
    investmentTier: 'Premium',
    image: '/images/property-1.jpg',
    galleryImages: ['/images/property-1.jpg', '/images/property-2.jpg', '/images/property-3.jpg'],
    amenities: ['Infinity Pool', 'Smart Home', 'Private Cinema', 'Gym', 'Generator', 'BQ', 'Security Post', 'Garden'],
    description: 'A masterpiece of contemporary architecture nestled in the heart of Lekki Phase 1. The Meridian Residence redefines what it means to live at the pinnacle of luxury in Lagos.',
    yearBuilt: 2024,
    status: 'Available',
  },
  {
    id: 'pw-002',
    title: 'Skyline Penthouse VI',
    tagline: 'Above the City, Above the Ordinary',
    location: 'Victoria Island',
    address: 'Adeola Odeku Street, Victoria Island',
    price: 1200000000,
    priceLabel: '₦1.2B',
    type: 'Penthouse',
    verified: true,
    featured: true,
    bedrooms: 4,
    bathrooms: 5,
    sqm: 680,
    roi: 22.1,
    investmentTier: 'Premium',
    image: '/images/property-2.jpg',
    galleryImages: ['/images/property-2.jpg', '/images/property-1.jpg', '/images/property-4.jpg'],
    amenities: ['360° Views', 'Private Terrace', 'Concierge', 'Valet Parking', 'Rooftop Pool', 'Smart Home'],
    description: 'Perched atop one of Victoria Island\'s most iconic towers, this duplex penthouse offers unrivaled panoramic views of the Lagos skyline and Atlantic Ocean.',
    yearBuilt: 2025,
    status: 'Available',
  },
  {
    id: 'pw-003',
    title: 'Lagoon Crest Estate',
    tagline: 'Your Private Waterfront Sanctuary',
    location: 'Ibeju-Lekki',
    address: 'Eleko Beach Road, Ibeju-Lekki',
    price: 2500000000,
    priceLabel: '₦2.5B',
    type: 'Estate',
    verified: true,
    featured: true,
    bedrooms: 8,
    bathrooms: 10,
    sqm: 3500,
    roi: 31.5,
    investmentTier: 'Premium',
    image: '/images/property-3.jpg',
    galleryImages: ['/images/property-3.jpg', '/images/property-5.jpg', '/images/property-1.jpg'],
    amenities: ['Private Beach', 'Boat Dock', 'Tennis Court', 'Helipad', 'Staff Quarters', 'Generator Farm', 'Lagoon Access'],
    description: 'An extraordinary waterfront compound on the shores of the Lekki Lagoon. Lagoon Crest Estate is the definitive address for those who demand the absolute best that Lagos has to offer.',
    yearBuilt: 2024,
    status: 'Available',
  },
  {
    id: 'pw-004',
    title: 'The Forest Green Manor',
    tagline: 'Nature-Inspired. Investment-Driven.',
    location: 'Lekki',
    address: 'Lekki Phase 2, Lagos',
    price: 450000000,
    priceLabel: '₦450M',
    type: 'Duplex',
    verified: true,
    featured: false,
    bedrooms: 5,
    bathrooms: 6,
    sqm: 890,
    roi: 16.2,
    investmentTier: 'High',
    image: '/images/property-4.jpg',
    galleryImages: ['/images/property-4.jpg', '/images/property-1.jpg', '/images/property-5.jpg'],
    amenities: ['Smart Home', 'Solar Power', 'Pool', 'Generator', 'Garden', 'BQ'],
    description: 'A sophisticated duplex masterfully designed to harmonize contemporary living with lush tropical surroundings. Ideal for the discerning Lagos executive.',
    yearBuilt: 2023,
    status: 'Available',
  },
  {
    id: 'pw-005',
    title: 'Coastal Reserve Townhouse',
    tagline: 'Prestige Living. Coastal Breathing.',
    location: 'Victoria Island',
    address: 'Kuramo Waters, Victoria Island',
    price: 380000000,
    priceLabel: '₦380M',
    type: 'Townhouse',
    verified: true,
    featured: false,
    bedrooms: 4,
    bathrooms: 4,
    sqm: 520,
    roi: 14.8,
    investmentTier: 'High',
    image: '/images/property-5.jpg',
    galleryImages: ['/images/property-5.jpg', '/images/property-2.jpg', '/images/property-3.jpg'],
    amenities: ['Ocean View', 'Private Garden', 'Pool Access', 'Generator', 'Security'],
    description: 'A refined townhouse in one of Victoria Island\'s most coveted gated communities, offering effortless coastal living with exceptional investment returns.',
    yearBuilt: 2023,
    status: 'Under Offer',
  },
  {
    id: 'pw-006',
    title: 'The Peninsula Collection',
    tagline: 'Where Tomorrow\'s Value Lives Today',
    location: 'Ibeju-Lekki',
    address: 'Dangote Refinery Axis, Ibeju-Lekki',
    price: 95000000,
    priceLabel: '₦95M',
    type: 'Land',
    verified: true,
    featured: false,
    bedrooms: 0,
    bathrooms: 0,
    sqm: 5000,
    roi: 42.0,
    investmentTier: 'High',
    image: '/images/property-3.jpg',
    galleryImages: ['/images/property-3.jpg', '/images/about-bg.jpg'],
    amenities: ['Survey Plan', 'C of O', 'Government Allocation', 'Waterfront Access', 'Road Access'],
    description: 'Strategic land investment plots along the Ibeju-Lekki corridor — Nigeria\'s fastest appreciating real estate zone, adjacent to the Dangote Refinery and Lekki Free Trade Zone.',
    yearBuilt: 2024,
    status: 'Available',
  },
];

export const formatPrice = (price: number): string => {
  if (price >= 1_000_000_000) {
    return `₦${(price / 1_000_000_000).toFixed(1)}B`;
  }
  return `₦${(price / 1_000_000).toFixed(0)}M`;
};

export const investorStats = [
  { label: 'Average ROI', value: '22.4%', sub: 'Annual Return' },
  { label: 'Properties Sold', value: '340+', sub: 'Since 2018' },
  { label: 'Total Value', value: '₦87B+', sub: 'Portfolio Managed' },
  { label: 'Client Satisfaction', value: '98%', sub: 'Repeat Investors' },
];
