# 🏡 Plusworld — Quiet Luxury Real Estate Portal

**Plusworld Realtors and Investment Limited** — A high-fidelity luxury real estate website built with React, Vite, and Tailwind CSS. Featuring cinematic animations, a full property portfolio, investor portal, and lead capture system.

---

## 🎨 Design System

| Token | Value | Usage |
|---|---|---|
| **Forest Green** | `#144d3c` | Primary brand color, text, CTA |
| **Dark Green** | `#0d3529` | Hero backgrounds, overlays |
| **Warm Beige** | `#fbe7c5` | Accents, highlights, badges |
| **Off-White** | `#fafaf8` | Page background |
| **Heading Font** | Cormorant Garamond | Display, titles |
| **Body Font** | Inter | UI, labels, body text |

---

## 🚀 Getting Started (Local Development)

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/plusworld-realestate.git
cd plusworld-realestate

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev

# 4. Build for production
npm run build
```

---

## 🌐 Deploying to GitHub Pages

### Option A: Manual Upload

1. Run `npm run build` — this generates `dist/index.html` (all-in-one file)
2. Create a new GitHub repository named `plusworld-website`
3. Upload the entire `dist/` folder to the `gh-pages` branch
4. Go to: **Repo Settings → Pages → Source: Deploy from branch → `gh-pages` / `root`**
5. Your site will be live at `https://YOUR_USERNAME.github.io/plusworld-website`

### Option B: GitHub Actions (Auto-Deploy)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm run build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

### Option C: Netlify (Easiest)
1. Go to [netlify.com](https://netlify.com)
2. Drag and drop the `dist/` folder
3. Done — live in under 60 seconds!

### Option D: Vercel
```bash
npm i -g vercel
vercel --prod
```

---

## 📁 Project Structure

```
plusworld/
├── public/
│   ├── images/           # Property & hero images
│   └── favicon.svg       # Brand favicon
├── src/
│   ├── components/
│   │   ├── Navbar.tsx         # Navigation + sticky tour button
│   │   ├── Footer.tsx         # Site footer
│   │   ├── PropertyCard.tsx   # Property card with hover effects
│   │   ├── TourModal.tsx      # Private viewing lead capture modal
│   │   └── AnimatedSection.tsx # Scroll-triggered animations
│   ├── pages/
│   │   ├── Home.tsx           # Cinematic hero + featured slider
│   │   ├── Listings.tsx       # Filterable property grid
│   │   ├── InvestorPortal.tsx # HNW investment landing page
│   │   ├── PropertyDetail.tsx # Full property page with gallery
│   │   └── About.tsx          # Team, values, contact
│   ├── data/
│   │   └── properties.ts      # CMS-style property data
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── vite.config.ts
└── package.json
```

---

## 🗄️ CMS Schema (Property Data Structure)

The `src/data/properties.ts` file acts as the CMS backend. To add a new property, append to the `properties` array:

```typescript
{
  id: 'pw-007',                      // Unique ID
  title: 'The Jade Residences',      // Property name
  tagline: 'Where Calm Meets Class', // Marketing tagline
  location: 'Lekki',                 // 'Lekki' | 'Victoria Island' | 'Ibeju-Lekki'
  address: 'Lekki Phase 1, Lagos',   // Full address
  price: 350000000,                  // Price in Naira (number)
  priceLabel: '₦350M',               // Display label
  type: 'Duplex',                    // 'Villa' | 'Penthouse' | 'Duplex' | 'Estate' | 'Townhouse' | 'Land'
  verified: true,                    // Show "Verified" badge
  featured: false,                   // Show in hero slider
  bedrooms: 4,
  bathrooms: 5,
  sqm: 650,
  roi: 17.5,                         // Annual ROI %
  investmentTier: 'High',            // 'Premium' | 'High' | 'Medium'
  image: '/images/property-6.jpg',   // Main image (place in public/images/)
  galleryImages: ['/images/...'],    // Additional gallery images
  videoUrl: 'https://...',           // Optional drone/walkthrough video URL
  amenities: ['Pool', 'Smart Home', 'Generator'],
  description: 'Full property description...',
  yearBuilt: 2024,
  status: 'Available',               // 'Available' | 'Under Offer' | 'Sold'
}
```

### To Upload New Property Images:
1. Place the image files in `public/images/`
2. Reference them as `/images/filename.jpg` in the data file
3. Recommended: 4K images (3840×2160px), max 2MB per image for web

---

## ✨ Features

- **Cinematic Hero** — Parallax scroll effect on hero image
- **Property Slider** — Auto-advancing featured properties carousel
- **Filterable Listings** — Filter by location, type, investment tier; sort by ROI/price
- **Property Detail Pages** — Full gallery with lightbox, investment analysis, sticky sidebar CTA
- **Investor Portal** — Investment corridors, diaspora section, FAQ accordion
- **Lead Capture Modal** — "Schedule Private Viewing" with form validation
- **Scroll Animations** — Intersection Observer-powered reveal animations
- **Sticky CTA Button** — "Book Private Viewing" always accessible
- **Mobile Responsive** — Full mobile navigation and layouts
- **About Page** — Team, values, awards, contact form

---

## 🔧 Customization

### Colors
Edit the CSS variables in `src/index.css`:
```css
:root {
  --forest-green: #144d3c;
  --warm-beige: #fbe7c5;
}
```

### Contact Information
Update the phone, email, and address in:
- `src/components/Navbar.tsx`
- `src/pages/About.tsx`
- `src/components/Footer.tsx`

### Brand Name
Search and replace "Plusworld" across all files to rebrand.

---

## 📞 Support

For technical support or customization requests, contact the development team.

---

*Built with React 19 + Vite 7 + Tailwind CSS 4 · © 2026 Plusworld Realtors and Investment Limited*
